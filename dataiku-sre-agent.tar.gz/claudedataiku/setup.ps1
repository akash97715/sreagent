# Dataiku SRE Agent - Windows Setup Script
# Run from the project root: .\setup.ps1

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "=== Dataiku SRE Agent - Windows Setup ===" -ForegroundColor Cyan
Write-Host ""

# ── 1. Fix hardcoded Mac path in agent definition ──────────────────────────────
$AgentFile = Join-Path $ProjectRoot ".claude\agents\dataiku-sre-monitor.md"
$MacPath   = "/Users/akasdeep/Desktop/claudedataiku/.claude/agent-memory/dataiku-sre-monitor/"
$WinPath   = "$ProjectRoot\.claude\agent-memory\dataiku-sre-monitor\"

if (Test-Path $AgentFile) {
    $content = Get-Content $AgentFile -Raw
    if ($content -match [regex]::Escape($MacPath)) {
        $content = $content -replace [regex]::Escape($MacPath), $WinPath
        Set-Content $AgentFile $content -NoNewline
        Write-Host "[OK] Agent memory path updated to: $WinPath" -ForegroundColor Green
    } else {
        Write-Host "[OK] Agent memory path already correct or not found (skipping)" -ForegroundColor Yellow
    }
}

# ── 2. Create observability\.env from .env.example if not exists ───────────────
$EnvFile    = Join-Path $ProjectRoot "observability\.env"
$EnvExample = Join-Path $ProjectRoot "observability\.env.example"

if (-Not (Test-Path $EnvFile)) {
    Copy-Item $EnvExample $EnvFile
    Write-Host ""
    Write-Host "[ACTION REQUIRED] Edit observability\.env and fill in your secrets:" -ForegroundColor Yellow
    Write-Host "  - Generate values: python -c ""import secrets; print(secrets.token_hex(32))""" -ForegroundColor White
    Write-Host "  - NEXTAUTH_SECRET, SALT, ENCRYPTION_KEY: generate 3 separate values" -ForegroundColor White
    Write-Host "  - LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY: get from Langfuse UI after first login" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host "[OK] observability\.env already exists" -ForegroundColor Green
}

# ── 3. Check Python + install dependencies ────────────────────────────────────
Write-Host ""
Write-Host "Checking Python dependencies..." -ForegroundColor Cyan
try {
    python --version | Out-Null
    pip install boto3 "langfuse>=2,<3" -q
    Write-Host "[OK] boto3 and langfuse installed" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Python/pip not found. Install Python 3.9+ and re-run." -ForegroundColor Yellow
}

# ── 4. Check Docker ───────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Checking Docker..." -ForegroundColor Cyan
try {
    docker info | Out-Null
    Write-Host "[OK] Docker is running" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Docker not running. Start Docker Desktop then re-run." -ForegroundColor Yellow
}

# ── 5. Set environment variables (session-scoped) ─────────────────────────────
Write-Host ""
Write-Host "Setting environment variable hints..." -ForegroundColor Cyan
Write-Host "  To set permanently, run these in PowerShell:" -ForegroundColor White
Write-Host '  [System.Environment]::SetEnvironmentVariable("CORP_IT_B_ACCOUNT_ID","<account-id>","User")' -ForegroundColor Gray
Write-Host '  [System.Environment]::SetEnvironmentVariable("DATAIKU_LOG_BUCKET","<bucket-name>","User")' -ForegroundColor Gray
Write-Host '  [System.Environment]::SetEnvironmentVariable("DATAIKU_LOG_PREFIX","dataiku/event-server/logs/","User")' -ForegroundColor Gray

# ── 6. Summary ────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "=== Next Steps ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Edit observability\.env with your secrets" -ForegroundColor White
Write-Host "2. Start Langfuse:" -ForegroundColor White
Write-Host "   docker compose -f observability\docker-compose.yml --env-file observability\.env up -d" -ForegroundColor Gray
Write-Host "3. Open http://localhost:3000 and create account + API keys" -ForegroundColor White
Write-Host "4. Add LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY to observability\.env" -ForegroundColor White
Write-Host "5. Run a demo trace:" -ForegroundColor White
Write-Host "   `$env:LANGFUSE_PUBLIC_KEY='pk-lf-...'" -ForegroundColor Gray
Write-Host "   `$env:LANGFUSE_SECRET_KEY='sk-lf-...'" -ForegroundColor Gray
Write-Host "   `$env:LANGFUSE_HOST='http://localhost:3000'" -ForegroundColor Gray
Write-Host "   `$env:DEMO_MODE='true'" -ForegroundColor Gray
Write-Host "   python sre_monitor.py" -ForegroundColor Gray
Write-Host ""
Write-Host "Setup complete." -ForegroundColor Green
