"""
Dataiku SRE Monitoring Agent - Full Cycle Runner
Performs parallel log analysis across 10 Dataiku nodes via S3.
Full Langfuse observability: nested spans, scores, generations, trace I/O.
"""

import boto3
import json
import sys
import os
import concurrent.futures
from datetime import datetime, timezone, timedelta
from botocore.exceptions import NoCredentialsError, ClientError

# ─── Langfuse Setup ─────────────────────────────────────────────────────────────
try:
    from langfuse import Langfuse
    _lf = Langfuse(
        public_key=os.environ.get("LANGFUSE_PUBLIC_KEY", "pk-lf-placeholder"),
        secret_key=os.environ.get("LANGFUSE_SECRET_KEY", "sk-lf-placeholder"),
        host=os.environ.get("LANGFUSE_HOST", "http://localhost:3000"),
    )
    LANGFUSE_ENABLED = True
except Exception as _e:
    print(f"[WARN] Langfuse not available: {_e}", file=sys.stderr)
    _lf = None
    LANGFUSE_ENABLED = False


class _Stub:
    """No-op stand-in when Langfuse is disabled."""
    id = "stub"
    def span(self, **kw):       return _Stub()
    def event(self, **kw):      return _Stub()
    def generation(self, **kw): return _Stub()
    def end(self, **kw):        return self
    def update(self, **kw):     return self
    def score(self, **kw):      return self


def new_trace(name, **kwargs):
    return _lf.trace(name=name, **kwargs) if LANGFUSE_ENABLED else _Stub()


def add_score(trace_id, name, value, comment=""):
    if LANGFUSE_ENABLED:
        _lf.score(trace_id=trace_id, name=name, value=value, comment=comment)


# ─── Configuration ──────────────────────────────────────────────────────────────
S3_BUCKET      = os.environ.get("DATAIKU_LOG_BUCKET", "dataiku-eventserver-logs-prod")
S3_PREFIX      = os.environ.get("DATAIKU_LOG_PREFIX", "dataiku/event-server/logs/")
AWS_REGION     = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
CORP_ACCOUNT   = os.environ.get("CORP_IT_B_ACCOUNT_ID", "")
DEMO_MODE      = os.environ.get("DEMO_MODE", "false").lower() == "true"
WINDOW_MINUTES = 10
NODE_COUNT     = 10
NODE_IDS       = [f"node-{str(i).zfill(2)}" for i in range(1, NODE_COUNT + 1)]

# ─── Time Window ────────────────────────────────────────────────────────────────
NOW          = datetime.now(timezone.utc)
WINDOW_END   = NOW
WINDOW_START = NOW - timedelta(minutes=WINDOW_MINUTES)
DATE_PATH    = NOW.strftime("%Y/%m/%d")
HOUR_PATH    = NOW.strftime("%H")

# ─── Simulated Log Data ─────────────────────────────────────────────────────────
SIMULATED_NODE_LOGS = {
    "node-01": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "SALES_PIPELINE",     "message": "Job COMPUTE_sales_metrics completed successfully in 42.3s"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "SALES_PIPELINE",     "message": "Scenario daily_refresh step 1/4 completed"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "INVENTORY_MGMT",     "message": "Recipe join_inventory_orders completed in 18.1s"},
    ]},
    "node-02": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "MARKETING_ANALYTICS","message": "Scenario weekly_cohort_analysis triggered by schedule"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "MARKETING_ANALYTICS","message": "Recipe compute_cohorts completed in 18.7s"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "MARKETING_ANALYTICS","message": "All scenario steps completed. Duration: 6m10s"},
    ]},
    "node-03": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "FINANCE_ETL",        "message": "Scenario nightly_financial_close triggered by schedule"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "FINANCE_ETL",        "message": "Recipe transform_gl_entries started"},
        {"time": NOW.isoformat(), "level": "ERROR",   "project": "FINANCE_ETL",
         "message": "RecipeFailureException: Recipe 'transform_gl_entries' (Python) failed.\n"
                    "  File \"/dataiku/recipes/FINANCE_ETL/transform_gl_entries.py\", line 87\n"
                    "MergeError: Merge keys are not unique in right dataset; not a many-to-one merge\n"
                    "[project: FINANCE_ETL] [recipe: transform_gl_entries] [type: Python]"},
        {"time": NOW.isoformat(), "level": "ERROR",   "project": "FINANCE_ETL",
         "message": "ScenarioAbortedException: Scenario 'nightly_financial_close' aborted at step 2. "
                    "Trigger: SCHEDULED. Start: 2026-05-02T19:43:55Z Abort: 2026-05-02T19:46:16Z"},
    ]},
    "node-04": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "CUSTOMER_360",       "message": "Recipe compute_customer_ltv started"},
        {"time": NOW.isoformat(), "level": "WARNING", "project": "CUSTOMER_360",
         "message": "Slow execution: Recipe 'compute_customer_ltv' (Spark) 180s elapsed. "
                    "Executor memory: 14.8GB / 16GB (92%). [project: CUSTOMER_360] [recipe: compute_customer_ltv] [type: Spark]"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "CUSTOMER_360",       "message": "Recipe compute_customer_ltv completed in 487.2s"},
    ]},
    "node-05": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "SUPPLY_CHAIN",       "message": "Recipe join_orders_shipments completed in 8.1s"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "SUPPLY_CHAIN",       "message": "Recipe forecast_demand completed in 275s"},
    ]},
    "node-06": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "DATA_QUALITY",       "message": "Scenario dq_checks_hourly triggered by API"},
        {"time": NOW.isoformat(), "level": "ERROR",   "project": "DATA_QUALITY",
         "message": "JobFailedException: OutOfMemoryError: Java heap space\n"
                    "  at BroadcastExchangeExec.doPrepare(BroadcastExchangeExec.scala:93)\n"
                    "Container killed by YARN: 16.4 GB of 16 GB physical memory used.\n"
                    "[project: DATA_QUALITY] [recipe: compute_dq_summary] [type: Spark]"},
        {"time": NOW.isoformat(), "level": "ERROR",   "project": "DATA_QUALITY",
         "message": "ScenarioAbortedException: Scenario 'dq_checks_hourly' aborted at step 1. "
                    "Trigger: API. Start: 2026-05-02T19:43:00Z Abort: 2026-05-02T19:43:46Z"},
    ]},
    "node-07": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "HR_ANALYTICS",       "message": "Recipe compute_headcount_trends started"},
        {"time": NOW.isoformat(), "level": "WARNING", "project": "HR_ANALYTICS",
         "message": "Disk space warning on ip-10-0-3-45: 82% used (410GB/500GB). "
                    "[project: HR_ANALYTICS] [recipe: compute_headcount_trends]"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "HR_ANALYTICS",       "message": "Recipe compute_headcount_trends completed in 205s"},
    ]},
    "node-08": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "PRODUCT_ANALYTICS",  "message": "Scenario feature_engineering_daily triggered by schedule"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "PRODUCT_ANALYTICS",  "message": "Recipe feature_extraction_v2 completed in 135s"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "PRODUCT_ANALYTICS",  "message": "Scenario feature_engineering_daily completed. All 3 steps successful."},
    ]},
    "node-09": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "RISK_SCORING",       "message": "Recipe score_credit_risk completed in 216s. 142,850 records scored."},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "RISK_SCORING",       "message": "Model serving endpoint refreshed with latest batch scores"},
    ]},
    "node-10": {"events": [
        {"time": NOW.isoformat(), "level": "INFO",    "project": "REALTIME_INGEST",    "message": "Streaming recipe kafka_consumer_orders started"},
        {"time": NOW.isoformat(), "level": "WARNING", "project": "REALTIME_INGEST",
         "message": "ConnectionTimeout: Kafka broker kafka-broker-03.internal:9092 unreachable after 30s. "
                    "Failing over to kafka-broker-04.internal:9092. "
                    "[project: REALTIME_INGEST] [recipe: kafka_consumer_orders]"},
        {"time": NOW.isoformat(), "level": "INFO",    "project": "REALTIME_INGEST",    "message": "Kafka consumer reconnected. Lag: 2,847 messages."},
    ]},
}


# ─── Gate Helpers ────────────────────────────────────────────────────────────────

def gate_1_saml_check(trace):
    span = trace.span(name="gate_1_saml_auth", input={"operation": "sts.get_caller_identity"})
    try:
        sts      = boto3.client("sts", region_name=AWS_REGION)
        identity = sts.get_caller_identity()
        arn      = identity["Arn"]
        account  = identity["Account"]
        role_seg = arn.split(":assumed-role/")[1].split("/")[0] if ":assumed-role/" in arn else ""
        is_saml  = any(k.lower() in role_seg.lower() for k in ("SAML", "SSO", "Federated", "Corp"))
        if not is_saml:
            span.end(level="ERROR", status_message=f"non-SAML role: {role_seg}",
                     output={"result": "FAIL", "reason": f"Role '{role_seg}' is not SAML-federated"})
            return False, arn, account, f"Role '{role_seg}' is not SAML-federated"
        span.end(output={"result": "PASS", "arn": arn, "account": account, "role": role_seg})
        return True, arn, account, None
    except NoCredentialsError as e:
        span.end(level="ERROR", status_message=str(e), output={"result": "FAIL", "reason": "NoCredentialsError"})
        return False, None, None, f"NoCredentialsError: {e}"
    except ClientError as e:
        span.end(level="ERROR", status_message=str(e), output={"result": "FAIL", "reason": "ClientError"})
        return False, None, None, f"ClientError: {e}"


def gate_2a_account_check(trace, account_id):
    span = trace.span(name="gate_2a_account_check",
                      input={"caller_account": account_id, "required_account": CORP_ACCOUNT or "not-configured"})
    if not CORP_ACCOUNT:
        span.end(output={"result": "SKIP", "reason": "CORP_IT_B_ACCOUNT_ID not set"})
        return True, None
    if account_id != CORP_ACCOUNT:
        reason = f"Account mismatch: caller={account_id} required={CORP_ACCOUNT}"
        span.end(level="ERROR", status_message=reason, output={"result": "FAIL"})
        return False, reason
    span.end(output={"result": "PASS", "account": account_id})
    return True, None


def gate_2b_s3_check(trace):
    span = trace.span(name="gate_2b_s3_access", input={"operation": "s3.head_bucket", "bucket": S3_BUCKET})
    try:
        boto3.client("s3", region_name=AWS_REGION).head_bucket(Bucket=S3_BUCKET)
        span.end(output={"result": "PASS", "bucket": S3_BUCKET})
        return True, None
    except ClientError as e:
        code   = e.response["Error"]["Code"]
        reason = f"HTTP {code} on bucket '{S3_BUCKET}'"
        span.end(level="ERROR", status_message=reason, output={"result": "FAIL", "error_code": code})
        return False, reason
    except NoCredentialsError as e:
        span.end(level="ERROR", status_message=str(e), output={"result": "FAIL"})
        return False, str(e)


# ─── Node Analysis ───────────────────────────────────────────────────────────────

def build_s3_url(node_id):
    return (f"s3://{S3_BUCKET}/{S3_PREFIX}{node_id}/"
            f"{DATE_PATH}/{HOUR_PATH}/eventserver-{node_id}-{NOW.strftime('%Y%m%dT%H%M')}Z.json")


def analyze_node(node_id, parent_span, s3_client=None, simulation=True):
    """Analyze a single node. parent_span is the parallel_node_analysis span."""
    s3_url    = build_s3_url(node_id)
    node_span = parent_span.span(
        name=f"analyze_{node_id}",
        input={"node_id": node_id, "s3_url": s3_url, "mode": "SIMULATION" if simulation else "LIVE"},
    )
    result = {
        "node_id": node_id, "s3_urls": [s3_url],
        "log_window": {"start": WINDOW_START.isoformat(), "end": WINDOW_END.isoformat()},
        "status": "UNKNOWN", "event_count": 0, "error_count": 0, "warning_count": 0,
        "errors": [], "warnings": [], "recipe_failures": [], "scenario_failures": [],
        "performance_metrics": {}, "raw_error_snippets": [],
        "fetch_method": "SIMULATED", "fetch_error": None,
    }

    # ── Fetch ──────────────────────────────────────────────────────────────────
    if s3_client and not simulation:
        fetch_span = node_span.span(name="s3_fetch", input={"bucket": S3_BUCKET, "key": s3_url.replace(f"s3://{S3_BUCKET}/", "")})
        try:
            key        = s3_url.replace(f"s3://{S3_BUCKET}/", "")
            obj        = s3_client.get_object(Bucket=S3_BUCKET, Key=key)
            raw        = json.loads(obj["Body"].read().decode("utf-8"))
            log_events = raw.get("events", [])
            result["fetch_method"] = "S3_LIVE"
            fetch_span.end(output={"status": "OK", "event_count": len(log_events)})
        except (ClientError, Exception) as e:
            result["fetch_error"]  = f"{type(e).__name__}: {e}"
            result["status"]       = "UNKNOWN"
            result["fetch_method"] = "S3_FAILED"
            fetch_span.end(level="ERROR", status_message=result["fetch_error"], output={"status": "FAIL"})
            node_span.end(level="ERROR", output=result)
            return result
    else:
        log_events = SIMULATED_NODE_LOGS.get(node_id, {"events": []})["events"]

    # ── Parse ──────────────────────────────────────────────────────────────────
    result["event_count"] = len(log_events)
    for ev in log_events:
        level   = ev.get("level", "INFO").upper()
        msg     = ev.get("message", "")
        project = ev.get("project", "UNKNOWN")
        ts      = ev.get("time", NOW.isoformat())

        if level in ("ERROR", "FATAL"):
            result["error_count"] += 1
            result["raw_error_snippets"].append({"time": ts, "project": project, "message": msg[:500]})
            if "RecipeFailureException" in msg or "[recipe:" in msg:
                recipe_name = next((p.replace("[recipe:", "").rstrip("]") for p in msg.split() if p.startswith("[recipe:")), "UNKNOWN")
                recipe_type = next((p.replace("[type:", "").rstrip("]")   for p in msg.split() if p.startswith("[type:")),   "UNKNOWN")
                result["recipe_failures"].append({"project": project, "recipe_name": recipe_name,
                                                  "recipe_type": recipe_type, "time": ts, "message": msg})
            if "ScenarioAbortedException" in msg or "JobFailedException" in msg:
                scenario_name = msg.split("Scenario '")[1].split("'")[0] if "Scenario '" in msg else "UNKNOWN"
                trigger       = msg.split("Trigger:")[1].split(".")[0].strip() if "Trigger:" in msg else "UNKNOWN"
                result["scenario_failures"].append({"project": project, "scenario_name": scenario_name,
                                                    "trigger": trigger, "time": ts, "message": msg})
            result["errors"].append({"time": ts, "project": project, "level": level, "message": msg})
        elif level == "WARNING":
            result["warning_count"] += 1
            result["warnings"].append({"time": ts, "project": project, "message": msg})
        if "completed in" in msg:
            try:
                duration = float(msg.split("completed in")[1].split("s")[0].strip())
                result["performance_metrics"][project] = f"{duration}s"
            except (ValueError, IndexError):
                pass

    result["status"] = ("CRITICAL" if result["error_count"] > 0
                        else "WARNING" if result["warning_count"] > 0
                        else "HEALTHY")

    lv = "ERROR" if result["status"] == "CRITICAL" else "WARNING" if result["status"] == "WARNING" else "DEFAULT"
    node_span.end(
        level=lv,
        output={
            "status":            result["status"],
            "event_count":       result["event_count"],
            "error_count":       result["error_count"],
            "warning_count":     result["warning_count"],
            "recipe_failures":   len(result["recipe_failures"]),
            "scenario_failures": len(result["scenario_failures"]),
            "s3_url":            s3_url,
        },
    )
    return result


def run_parallel_analysis(trace, simulation=True):
    s3_client    = None if simulation else boto3.client("s3", region_name=AWS_REGION)
    analysis_span = trace.span(
        name="parallel_node_analysis",
        input={"nodes": NODE_IDS, "node_count": NODE_COUNT, "mode": "SIMULATION" if simulation else "LIVE"},
    )

    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=NODE_COUNT) as executor:
        futures = {executor.submit(analyze_node, nid, analysis_span, s3_client, simulation): nid for nid in NODE_IDS}
        for future in concurrent.futures.as_completed(futures):
            nid = futures[future]
            try:
                results[nid] = future.result()
            except Exception as e:
                results[nid] = {
                    "node_id": nid, "s3_urls": [build_s3_url(nid)], "status": "UNKNOWN",
                    "error_count": 0, "warning_count": 0, "event_count": 0,
                    "errors": [], "warnings": [], "recipe_failures": [], "scenario_failures": [],
                    "performance_metrics": {}, "raw_error_snippets": [],
                    "fetch_error": f"{type(e).__name__}: {e}",
                    "log_window": {"start": WINDOW_START.isoformat(), "end": WINDOW_END.isoformat()},
                }

    ordered = {nid: results[nid] for nid in NODE_IDS}
    statuses = [r["status"] for r in ordered.values()]
    summary  = {
        "total_events":   sum(r["event_count"]   for r in ordered.values()),
        "total_errors":   sum(r["error_count"]   for r in ordered.values()),
        "total_warnings": sum(r["warning_count"] for r in ordered.values()),
        "critical_nodes": statuses.count("CRITICAL"),
        "warning_nodes":  statuses.count("WARNING"),
        "healthy_nodes":  statuses.count("HEALTHY"),
        "unknown_nodes":  statuses.count("UNKNOWN"),
    }
    lv = "ERROR" if summary["critical_nodes"] > 0 else "WARNING" if summary["warning_nodes"] > 0 else "DEFAULT"
    analysis_span.end(level=lv, output=summary)
    return ordered, summary


# ─── Main ────────────────────────────────────────────────────────────────────────

def main():
    user_id = "demo-user@corp.com" if DEMO_MODE else os.environ.get("USER", "unknown")

    trace = new_trace(
        name="dataiku-sre-monitoring-cycle",
        user_id=user_id,
        input={
            "request":      "cluster health check",
            "window_start": WINDOW_START.isoformat(),
            "window_end":   WINDOW_END.isoformat(),
            "nodes":        NODE_IDS,
            "s3_bucket":    S3_BUCKET,
            "demo_mode":    DEMO_MODE,
        },
        metadata={"s3_prefix": S3_PREFIX, "aws_region": AWS_REGION},
        tags=["dataiku", "sre", "monitoring"] + (["demo"] if DEMO_MODE else ["live"]),
    )

    # ── Gates ───────────────────────────────────────────────────────────────────
    if DEMO_MODE:
        arn, account_id = "arn:aws:sts::123456789012:assumed-role/SAML-DataikuSRE/demo-user@corp.com", "123456789012"
        trace.span(name="gate_1_saml_auth",      input={"mode": "DEMO"}).end(output={"result": "PASS", "arn": arn})
        trace.span(name="gate_2a_account_check", input={"mode": "DEMO"}).end(output={"result": "PASS", "account": account_id})
        trace.span(name="gate_2b_s3_access",     input={"mode": "DEMO"}).end(output={"result": "PASS", "mode": "SIMULATION"})
        simulation = True
        print("MODE=DEMO — all gates bypassed with synthetic identity", file=sys.stderr)
    else:
        saml_ok, arn, account_id, saml_err = gate_1_saml_check(trace)
        if not saml_ok:
            trace.update(output={"result": "ACCESS_DENIED", "gate": 1, "reason": saml_err})
            print(json.dumps({"gate": 1, "result": "ACCESS_DENIED", "reason": saml_err}, indent=2))
            if LANGFUSE_ENABLED: _lf.flush()
            sys.exit(1)

        acct_ok, acct_err = gate_2a_account_check(trace, account_id)
        if not acct_ok:
            trace.update(output={"result": "ACCESS_DENIED", "gate": "2a", "reason": acct_err})
            print(json.dumps({"gate": "2a", "result": "ACCESS_DENIED", "reason": acct_err}, indent=2))
            if LANGFUSE_ENABLED: _lf.flush()
            sys.exit(1)

        s3_ok, s3_err = gate_2b_s3_check(trace)
        simulation = not s3_ok
        if not s3_ok:
            print(f"[WARN] S3 gate: {s3_err} — SIMULATION mode", file=sys.stderr)

    mode = "SIMULATION" if simulation else "LIVE"
    print(f"MODE={mode}", file=sys.stderr)

    # ── Analysis ────────────────────────────────────────────────────────────────
    node_results, summary = run_parallel_analysis(trace, simulation=simulation)

    cluster_status = ("CRITICAL" if summary["critical_nodes"] > 0
                      else "DEGRADED" if summary["warning_nodes"] > 0
                      else "HEALTHY")

    # ── Generation: records the SRE analysis as an observable unit with usage ──
    # This populates the Usage tab in Langfuse with events_processed / issues_found
    trace.generation(
        name="sre_cluster_analysis",
        model="dataiku-sre-monitor-v1",
        input={
            "nodes_analyzed": NODE_COUNT,
            "window_minutes": WINDOW_MINUTES,
            "mode":           mode,
        },
        output={
            "cluster_status":  cluster_status,
            "critical_nodes":  summary["critical_nodes"],
            "warning_nodes":   summary["warning_nodes"],
            "healthy_nodes":   summary["healthy_nodes"],
            "total_errors":    summary["total_errors"],
            "total_warnings":  summary["total_warnings"],
        },
        usage={
            "input":  summary["total_events"],    # events ingested = "input tokens"
            "output": summary["total_errors"] + summary["total_warnings"],  # issues = "output tokens"
            "unit":   "CHARACTERS",               # closest Langfuse unit for custom metrics
        },
    )

    # ── Scores ──────────────────────────────────────────────────────────────────
    # Overall cluster health: 1.0 = fully healthy, 0.0 = all critical
    health_score = round(summary["healthy_nodes"] / NODE_COUNT, 2)
    add_score(trace.id, "cluster_health_score", health_score,
              comment=f"{summary['healthy_nodes']}/{NODE_COUNT} nodes healthy")

    error_rate = round(summary["total_errors"] / max(summary["total_events"], 1), 4)
    add_score(trace.id, "error_rate", error_rate,
              comment=f"{summary['total_errors']} errors in {summary['total_events']} events")

    # ── Final trace output ───────────────────────────────────────────────────────
    trace.update(
        output={
            "cluster_status": cluster_status,
            **summary,
            "mode": mode,
            "identity": arn,
        }
    )

    output = {
        "cycle_metadata": {
            "report_timestamp": NOW.isoformat(),
            "window_start":     WINDOW_START.isoformat(),
            "window_end":       WINDOW_END.isoformat(),
            "s3_bucket":        S3_BUCKET,
            "aws_region":       AWS_REGION,
            "node_count":       NODE_COUNT,
            "simulation_mode":  simulation,
            "cluster_status":   cluster_status,
            **summary,
        },
        "node_results": node_results,
    }
    print(json.dumps(output, indent=2))

    if LANGFUSE_ENABLED:
        _lf.flush()
        print(f"\n[TRACE] http://localhost:3000/project/cmoot0f990006xe32qylb2uer/traces/{trace.id}", file=sys.stderr)


if __name__ == "__main__":
    main()
